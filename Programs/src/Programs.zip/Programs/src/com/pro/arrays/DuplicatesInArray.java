package com.pro.arrays;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class DuplicatesInArray {

	public static void main(String[] args) {

//setMeth();

		int[] arr = { 4,9,4,7,8,8,5,8,8,9 };
		int[]d= removeDuplicates(arr);
		for (int i : d) {

			System.out.print(i);

		}
		
		System.out.println(removeDuplicates2(arr).toString());

	}

	public static int[] removeDuplicates(int[] arr) {

		Arrays.sort(arr);

		Set<Integer> set = new HashSet<>();

		for(int i=0;i<arr.length-1;i++) {

	

				set.add(arr[i]);
			}

		int[] b=new int[set.size()];

		int c=0;
		for (int i : set) {

			b[c]=i;
			c++;

		}

		return b;
	}
	
	
	public static Set<Integer> removeDuplicates2(int[] arr) {
		
		
		Set<Integer> unique= new HashSet<>();
		Set<Integer> duplSet= new HashSet<>();
		
		for(int x:arr) {
			
			if(!unique.add(x)) {
				
				duplSet.add(x);
			}
		}
		return duplSet;
		
		
		
		
		
	}
	
	
	public static void setMeth() {
		int arr[]= {1,5,7,9,4,99,99,78,0,4,1};
		Set<Integer> s = new HashSet<>();
		Set<Integer> s2 = new HashSet<>();

		for(Integer c : arr) {



			if(!s.add(c)) {

				s2.add(c);
			}
		}

		System.out.println(s2.toString());
	}

}
