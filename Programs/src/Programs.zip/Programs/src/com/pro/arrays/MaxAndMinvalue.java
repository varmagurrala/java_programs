package com.pro.arrays;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MaxAndMinvalue {

	public static void main(String[] args) {
		int arr[]= {2,5,7,9,7,8,7,5,54,9,5};
		

		app1(arr);
		app2(arr);

	}

	public static void app1(int arr[]) {
		List<Integer> s = new ArrayList<>();

		for(int i:arr) {
			s.add(i);
		}

		int orElse = s.stream().mapToInt(Integer::valueOf).max().orElse(0);

		System.out.println(orElse);

	}

	public static void app2(int arr[]) {
		List<Integer> s = new ArrayList<>();

		for(int i:arr) {
			s.add(i);
		}

		List<Integer> collect = s.stream().sorted((o1,o2)->o2-o1).collect(Collectors.toList());
		int orElse = collect.stream().mapToInt(Integer::valueOf).distinct().skip(1).findFirst().orElse(0);
		System.out.println(orElse);

	}

}
