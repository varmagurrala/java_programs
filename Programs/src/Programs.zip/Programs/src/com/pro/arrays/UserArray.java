package com.pro.arrays;

import java.util.Scanner;

public class UserArray {
	public static void main(String[] args) {
		
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter array size");
		
		int size=sc.nextInt();
		
		int count=1;
		int arr [] =new int[size];
		
		for(int i=0;i<size
				;i++ ) {
			
			System.out.println("enter 1 value"+count);
			
			
			arr[i]=sc.nextInt();
			
			count++;
			
			if(count==size+1) {
				System.out.println("array is filled");
			}
			
		}
	}

}
