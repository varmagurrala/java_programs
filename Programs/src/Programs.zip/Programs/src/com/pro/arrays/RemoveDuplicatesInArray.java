package com.pro.arrays;

import java.util.Arrays;

public class RemoveDuplicatesInArray {
	public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 2, 5, 6, 1, 7, 8, 9, 3, 10};
        int[] uniqueArray = removeDuplicates(arr);
        
        System.out.println("Original Array: " + Arrays.toString(arr));
        System.out.println("Array without Duplicates: " + Arrays.toString(uniqueArray));
    }

    public static int[] removeDuplicates(int[] arr) {
        // Sort the array to bring duplicates together
        Arrays.sort(arr);

        // Count the number of unique elements
        int uniqueCount = 1;
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] != arr[i - 1]) {
                uniqueCount++;
            }
        }

        // Create a new array with the unique elements
        int[] uniqueArray = new int[uniqueCount];
        uniqueArray[0] = arr[0];
        int currentIndex = 1;

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] != arr[i - 1]) {
                uniqueArray[currentIndex] = arr[i];
                currentIndex++;
            }
        }

        return uniqueArray;
    }
}
