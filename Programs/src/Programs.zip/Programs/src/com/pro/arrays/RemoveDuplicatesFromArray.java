package com.pro.arrays;

import java.util.Arrays;

public class RemoveDuplicatesFromArray {
	public static void main(String[] args) {

		int[] arr = {1, 2, 3, 4, 2, 5, 6, 1, 7, 8, 9, 3, 10,10,10};

		remove(arr);

	}

	public static void remove(int arr[]) {

		Arrays.sort(arr);
		
		int duplCount=1;
		
		for(int i=1;i<arr.length;i++) {
			if(arr[i]!=arr[i-1]) {
				duplCount++;
			} 

		}


		int[] arr2= new int[duplCount];


		arr2[0]=arr[0];

		int uni=1;

		for(int i=1;i<arr.length;i++) {

			if(arr[i]!=arr[i-1]) {

				arr2[uni]=arr[i];

				uni++;

			}
		}

		System.out.println(Arrays.toString(arr2));


	}



}
