package com.pro.strings;


	import java.util.HashMap;
import java.util.Map;
	import java.util.function.Function;
	import java.util.stream.Collectors;

	public class Occu3OfChar {
		public static void main(String[] args) {
			String s ="hakunaumatata";

			Map<Character, Integer> mp= new HashMap<>();
			
			for(char c:s.toCharArray()) {
				if(mp.containsKey(c)) {
					
					mp.put(c, mp.get(c)+1);
				}
				else {
					mp.put(c, 1);
				}
			}
			

	        // Finding second highest value and corresponding key
	        Map.Entry<Character, Integer> secondHighestEntry = mp.entrySet().stream()
	                .sorted(Map.Entry.<Character,Integer>comparingByValue().reversed()).distinct()
	                .skip(2) // Skip the first entry (highest occurrence)
	                .findFirst()
	                .orElse(null);

	        if (secondHighestEntry != null) {
	            System.out.println("Second highest occurrence: " + secondHighestEntry.getKey() + " : " + secondHighestEntry.getValue());
	        }
			
			


		}
	}



