package com.pro.strings;

public class RemoveAGivenCharacter {
	
	
public static void main(String[] args) {
	

	String s= "ram gopal,varma";
	String s2=s.replaceAll("\\W+", "");
	String s3="";
	for(char c : s2.toCharArray()) {
		if(c !='a') {
			s3=s3+c;
		}
	}
	System.out.println(s3);
	
}

}
