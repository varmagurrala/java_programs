package com.pro.strings;

public class ConvertAStringToAnInteger { 
	
	public static void main(String[] args) {
		
		String s ="12345";
		
		int i=Integer.parseInt(s);
		
		System.out.println(i);
	
}

}
