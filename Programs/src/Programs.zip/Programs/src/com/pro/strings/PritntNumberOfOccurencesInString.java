package com.pro.strings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PritntNumberOfOccurencesInString {
	
	    public static void main(String[] args) {
	        String s = "hakunamatata";

	        char[] sc = s.toCharArray();

	        List<Character> charList = new ArrayList<>();
	        for (char c : sc) {
	            charList.add(c);
	        }

	        Set<Character> charSet = new HashSet<>(charList);

	        for (char c : charSet) {
	            int frequency = Collections.frequency(charList, c);
	            System.out.println(c + " : " + frequency);
	        }
	    }

}
