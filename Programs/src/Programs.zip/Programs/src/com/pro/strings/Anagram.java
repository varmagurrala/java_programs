package com.pro.strings;

import java.util.Arrays;

public  final class Anagram {
	public static void main(String[] args) {

		String str1 = "listen";
		String str2 = "silent";

		char[] charArray1 = str1.toCharArray();
		char[] charArray2 = str2.toCharArray();

		Arrays.sort(charArray1);
		Arrays.sort(charArray2);

		String s1=Arrays.toString(charArray1);
		String s2=Arrays.toString(charArray2);






		if(s1.equalsIgnoreCase(s2)) {
			System.out.println("anagram");
		}
		else {
			System.out.println("not");
		}
	}

}
