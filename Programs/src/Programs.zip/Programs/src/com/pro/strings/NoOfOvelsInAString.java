package com.pro.strings;

public class NoOfOvelsInAString {
	
	public static void main(String[] args) {
		String s="ram gopal varma";
		String s2=s.replaceAll("\\W+", "");
		char c[]= s2.toCharArray();
		int count =0;
		for(char g : c) {
			
			if(g=='a'||g=='e'||g=='i'||g=='o'||g=='u') {
				count++;
			}
		}
		
		System.out.println(count);
	}

}
