package com.pro.strings;

import java.util.LinkedHashMap;
import java.util.Map;

public class FirstNonRepeatingChar {
public static void main(String[] args) {
	
	 String s ="starinags";
		
	   Map<Character, Integer> mp = new LinkedHashMap<>();
	   
	   for(char c:s.toCharArray()) {
		   
		   if(mp.containsKey(c)) {
			   
			   mp.put(c, mp.get(c)+1);
		   }
		   else {
			   
			   mp.put(c, 1);
		   }
	   }
	   
	   for(char v:s.toCharArray()) {
		   
		   if(mp.get(v)==1) {
			   System.out.println(v);
			   break;
		   }
	   }}
}
