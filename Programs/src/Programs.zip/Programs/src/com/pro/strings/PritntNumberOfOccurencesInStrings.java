package com.pro.strings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PritntNumberOfOccurencesInStrings {
	
	
	public static void main(String[] args) {
		String s="ram ram sita hanu hanu,hanu";
		
		String[] s2= s.split("\\W+");
		
		List<String> list= new ArrayList<>();
		for(String a:s2) {
			
			list.add(a);
		}
		
		Set<String> set= new HashSet<>(list);
		
		for(String word:set) {
			
			if(word.equals("hanu")) {
				
				int fre=Collections.frequency(list,word);
				
				System.out.println(word+" : "+fre);
			}
			
		
		}
	}

}
