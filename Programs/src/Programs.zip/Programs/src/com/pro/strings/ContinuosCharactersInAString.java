package com.pro.strings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ContinuosCharactersInAString {

	public static void main(String[] args) {
		String str = "abccddeefghi";

		withStream(str);
		withFreq(str);
		withnormal(str);




	}

	public static void withStream(String s)
	{
		Map<Character, Long> a= s.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

		System.out.println(a);
	}
	public static void withFreq(String s)
	{
		List<Character> li= new ArrayList<>();

		for(char h:s.toCharArray()) {
			li.add(h);
		}

		Set<Character> si = new HashSet<>(li);

		for(char c:si) {

			int frweq=Collections.frequency(li, c);

			System.out.println(c+": "+frweq);
		}


	}
	public static void withnormal(String s)
	{


		Map<Character, Integer> ss= new HashMap<>();

		for(char c:s.toCharArray()) {

			if(ss.containsKey(c)) {

				ss.put(c,ss.get(c)+1);
			}
			else {
				ss.put(c, 1);
			}
		}

		System.out.println(ss);


	}

}

