package com.pro.strings;

import java.util.Arrays;

public class RemoveSteingDupNoCollections {


	public static void main(String[] args) {

		//		int[] arr = {1, 2, 3, 4, 2, 5, 6, 1, 7, 8, 9, 3, 10,10,10};

		String s="hakunamatata name is kurma is kurma";

		String []arr=s.split(" ");

		Arrays.sort(arr);

		for(String k:arr) {
			System.out.println(k);
		}

		int dup=1;

		for(int i=1;i<arr.length;i++) {
			if(!arr[i].equalsIgnoreCase(arr[i-1])) {

				dup++;
			}
		}

		String arr2[] =new String[dup];

		int uni=1;

		arr2[0]=arr[0];

		for(int i=1;i<arr.length;i++) {
			if(!arr[i].equalsIgnoreCase(arr[i-1]) ) {
				arr2[uni]=arr[i];

				uni++;
			}
		}



		System.out.println(Arrays.toString(arr2));




	}

}
