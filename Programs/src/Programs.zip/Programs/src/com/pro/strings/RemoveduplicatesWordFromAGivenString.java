package com.pro.strings;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveduplicatesWordFromAGivenString {
	
	public static void main(String[] args) {
		String s="ram gopal varma ram gopal,sherma";
		
		String[] s2=s.split("\\W+");
		
		Set<String> set = new LinkedHashSet<>();
		
		for(String s4:s2) {
			
			set.add(s4);
			
		}
		
		System.out.println(set.toString());
	}

}
