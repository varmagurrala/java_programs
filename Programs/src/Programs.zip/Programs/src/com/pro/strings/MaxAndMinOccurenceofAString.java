package com.pro.strings;

import java.util.HashMap;
import java.util.Map;

public class MaxAndMinOccurenceofAString {
	public static void main(String[] args) {
		String s ="hakunaumatata";

		Map<Character, Integer> mp= new HashMap<>();
		
		for(char c:s.toCharArray()) {
			if(mp.containsKey(c)) {
				
				mp.put(c, mp.get(c)+1);
			}
			else {
				mp.put(c, 1);
			}
		}
		
		System.out.println(mp);

        // Finding second highest value and corresponding key
        Map.Entry<Character, Integer> secondHighestEntry = mp.entrySet().stream()
                .sorted((o1,o2)->o2.getValue()-o1.getValue()).distinct()
                .skip(1) // Skip the first entry (highest occurrence)
                .findFirst()
                .orElse(null);

        if (secondHighestEntry != null) {
            System.out.println("Second highest occurrence: " + secondHighestEntry.getKey() + " : " + secondHighestEntry.getValue());
        }
		
		


	}

}
