package com.pro.strings;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MostFrequentWord {
	
	public static void main(String[] args) {
		
		
		String names="ram,sam,ram,jam,sam,tom,sam,ram,ram";
		
		String[] str=names.split("\\W+");
		
		Map<String, Long> fq= Arrays.asList(str).stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		Map.Entry<String, Long> l= fq.entrySet().stream().max(Map.Entry.comparingByValue()).orElse(null);
		
		if(l!=null) {
			System.out.println(l.getKey()+" : "+l.getValue());
		}
		else {
			
			System.out.println("string not found");
		}
		
		
		
	}

}
