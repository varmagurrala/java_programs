package com.pro.strings;

public class CountTheGivenCharacter {

	public static void main(String[] args) {
		
		String s="india";
		
		System.out.println(charCount(s, 'a'));
		
	}
	
	public static int charCount(String s, char c) {
		
		int count=0;
		
		for(char c2:s.toCharArray()) {
			
			if(c2==c) {
				
				count++;
			}
		}
		
		return count;
	}

}
