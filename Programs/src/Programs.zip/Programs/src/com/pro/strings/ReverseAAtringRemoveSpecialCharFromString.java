package com.pro.strings;

public class ReverseAAtringRemoveSpecialCharFromString {

	public static void main(String[] args) {

		
		String s= "hsdhsdjsjd@ksldjs#sdlkldk(;]";
		String s2=s.replaceAll("\\W+", "");
		System.out.println(s2);
	}

}
