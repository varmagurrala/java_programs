package com.pro.strings;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MostFrequentCharacter {
	public static void main(String[] args) {
        String str = "Hello, World!";
        
        // Convert the string to a stream of characters
        Map<Character, Long> charFrequencies = str.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        // Find the character with the highest frequency
        Map.Entry<Character, Long> mostFrequentEntry = charFrequencies.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .orElse(null);

        // Display the most frequent character
        if (mostFrequentEntry != null) {
            System.out.println("Most frequent character: " + mostFrequentEntry.getKey()
                    + " (Frequency: " + mostFrequentEntry.getValue() + ")");
        } else {
            System.out.println("No characters found.");
        }
    }

}
