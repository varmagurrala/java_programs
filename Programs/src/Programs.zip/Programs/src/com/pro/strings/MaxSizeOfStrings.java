package com.pro.strings;

public class MaxSizeOfStrings {
	public static void main(String[] args) {
		int maxLength =0;
		String word="";
		String s="varma varmaa  ramarao is a bad.boy";
		String s2[]=s.split("\\W+");

		for(String s1: s2) {
			int length=s1.length();
			if(length>maxLength) {
				maxLength=length;
				word=s1;
			}

		}

		System.out.println(maxLength+""+word);


	}

}
