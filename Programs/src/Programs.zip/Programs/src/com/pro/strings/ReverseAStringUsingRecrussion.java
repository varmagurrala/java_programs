package com.pro.strings;

public class ReverseAStringUsingRecrussion {
	
	public static void main(String[] args) {
        String str = "Hello, World!";
        String reversedStr = reverseString(str);

        System.out.println("Original string: " + str);
        System.out.println("Reversed string: " + reversedStr);
    }

    private static String reverseString(String str) {
        // Base case: If the string is empty or has only one character, return the string as it is
        if (str.isEmpty() || str.length() == 1) {
            return str;
        }

        // Recursive case: Reverse the substring starting from the second character
        // and append the first character at the end
        return reverseString(str.substring(1)) + str.charAt(0);
    }
}
