package com.pro.theory;

public class Triangle implements Draw {

	@Override
	public void draw() {
System.out.println("in the triangle");		
	}
	
	

}
