package com.pro.theory;

public interface Draw {
	
	void draw();

}
