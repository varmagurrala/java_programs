package com.pro.theory;

public class Circle implements Draw {

	@Override
	public void draw() {
System.out.println("in circle class");		
	}

}
