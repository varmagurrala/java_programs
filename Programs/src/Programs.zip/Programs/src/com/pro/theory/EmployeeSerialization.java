package com.pro.theory;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class EmployeeSerialization implements Serializable {


	private static final long serialVersionUID = 1L;
	int Eid;
	String Ename;
	double Esalary;
	transient String Eaadhar;

	public EmployeeSerialization(int eid, String ename, double esalary, String eaadhar) {
		super();

		Eid = eid;
		Ename = ename;
		Esalary = esalary;
		Eaadhar = eaadhar;
	}

	public static void main(String[] args) {
		EmployeeSerialization emp = new EmployeeSerialization(1234, "varma", 1214, "123456789");

		try {
			FileOutputStream out= new FileOutputStream("E:\\kishore.ser");
			ObjectOutputStream file= new ObjectOutputStream(out);
			file.writeObject(emp);
			out.close();
			file.close();
			System.out.println("Serialization Sucess");
		} catch (Exception e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();	
		} 


	}



}
