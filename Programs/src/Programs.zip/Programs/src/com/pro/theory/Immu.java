package com.pro.theory;

public  class Immu {

	
	private static Immu immu=null;
	
	private Immu() {
		
	}
	
	public synchronized Immu getIns() {
		
		if(immu==null) {
			immu= new  Immu();
		}
		return immu;
	}
	







	public static void main(String[] args) {
		
	}


}
