package com.pro.theory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class EmployeeDeSerialization {

	public static void main(String[] args) {

		try {
			FileInputStream filein= new FileInputStream("E:\\kishore.ser");
			ObjectInputStream fileo= new ObjectInputStream(filein);
			EmployeeSerialization ED = (EmployeeSerialization) fileo.readObject();
			
			System.out.println("Employee Id: " + ED.Eid);
			System.out.println("Employee Name:" + ED.Ename);
			System.out.println("Employee Salary:" + ED.Esalary);
			System.out.println("Employee Aadhar Number: " + ED.Eaadhar);

			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
