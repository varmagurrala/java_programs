package com.pro.exceptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ConcurentModException {
	public static void main(String[] args) {
		List<String> myList = new ArrayList<>(Arrays.asList("one", "two", "three"));

		Iterator<String> iterator = myList.iterator();
		while (iterator.hasNext()) {
		    String element = iterator.next();
		    myList.remove(element); // ConcurrentModificationException will occur
		}
	}

}
