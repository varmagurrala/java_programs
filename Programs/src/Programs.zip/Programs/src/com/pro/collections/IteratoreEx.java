package com.pro.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.pro.streams.Employee;

public class IteratoreEx {

	public static void main(String[] args) {

		
		List<Employee> e= Employee.getListOfEmployees();
		
		Set<Employee> e2= new HashSet<>(e);
		
		
		Iterator<Employee> i= e2.iterator();
		
		while (i.hasNext()) {
			
		Employee emp= i.next();
		System.out.println(emp);
			
		}
	}

}
