package com.pro.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CompDummy {
	
	public static void main(String[] args) {
		
		List<Employee> e = new ArrayList<>();
	    e.add(new Employee(3, "ravi", 100));
	    e.add(new Employee(2, "ram", 400));
	    e.add(new Employee(5, "abhi", 300));
	    
		Comparator<Employee> com = (o1,o2)->o1.getName().compareTo(o2.getName());
		
		Collections.sort(e, com.reversed());
		
		System.out.println(e);
		
		
	}

}
