package com.pro.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapIterator {
	
	public static void main(String[] args) {
		
		Map<Integer, String> mm= new  HashMap<>();
		
		mm.put(1, "varma");
		mm.put(2, "chanti");
		mm.put(3, "charan");
		
		
		for(Map.Entry<Integer, String> map:mm.entrySet()) {
			
			System.out.println(map.getKey()+":"+map.getValue());
		}
	}

}
