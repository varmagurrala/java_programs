package com.pro.multithreadg;

public class ThreadEx  extends Thread{
	
	public void run() {
		
		System.out.println("in extends run");
	}
	
	

}
