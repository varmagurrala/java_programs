package com.pro.multithreadg;

public class ThreadDec implements Runnable {

	@Override
	public void run() {

		System.out.println("in run method");
	}

}
