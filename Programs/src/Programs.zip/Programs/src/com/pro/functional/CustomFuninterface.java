package com.pro.functional;

import java.util.function.Function;

@FunctionalInterface
public interface CustomFuninterface   {
	
	void name(String s);
	

}
