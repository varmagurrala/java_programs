package com.pro.functional;

public interface CustomFuninterfaces {
	
	default void mani() {
		
		System.out.println("ram");
	}

}
