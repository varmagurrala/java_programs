package com.pro.practice;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;
public final  class Dummy {
	
	

	 public static void main(String[] args) {
		  String a = "saabbccddeeffffs";
		
	    }	
	


}


