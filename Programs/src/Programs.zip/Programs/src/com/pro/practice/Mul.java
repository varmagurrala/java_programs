package com.pro.practice;

public class Mul extends Thread {

	@Override
	public void run() {
		
		Thread.yield();

		for(int i=0;i<10;i++) {
			
			
			
			System.out.println("in mul"+i);
		}
	}

}
