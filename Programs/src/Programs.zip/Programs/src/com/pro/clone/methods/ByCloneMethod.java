package com.pro.clone.methods;

public class ByCloneMethod implements Cloneable {
	
	int a;
	

	public ByCloneMethod(int a) {
		super();
		this.a = a;
	}
	
	

	public void setA(int a) {
		this.a = a;
	}




	public static void main(String[] args) throws CloneNotSupportedException {

		
		ByCloneMethod b = new ByCloneMethod(5);
		
		ByCloneMethod c= (ByCloneMethod) b.clone();
		System.out.println(b.a);
		
		System.out.println(c.a);
		c.setA(3);
		
		System.out.println(c.a);
		
		System.out.println(b.a);
		System.out.println(c.a);
	}

}
