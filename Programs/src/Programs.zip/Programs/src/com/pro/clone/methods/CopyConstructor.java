package com.pro.clone.methods;

public class CopyConstructor {
	
	int field;
	
	public void setField(int field) {
		this.field = field;
	}

	public CopyConstructor(int field) {
		super();
		this.field = field;
	}
	public CopyConstructor(CopyConstructor cc) {
		super();
		this.field = cc.field;
	}

	public static void main(String[] args) {
		
		CopyConstructor c1= new CopyConstructor(1);
		CopyConstructor c2 = new  CopyConstructor(c1);
		System.out.println(c1.field);
		System.out.println(c2.field);
		c2.setField(4);
		System.out.println(c1.field);
		System.out.println(c2.field);
		
		
		
	}

}
