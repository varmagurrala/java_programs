package com.pro.Inheritance;

public class OverLoadExp {

	public static void m1(String s) {

		System.out.println("in String s");
	}
	
	public static void m1(String s,String s2) {

		System.out.println("in String s,String s2");
	}
	
	public static void m1(int s,String s2) {

		System.out.println("in int s,String s2");
	}
	
	public static void m1(String s,int s2) {

		System.out.println("in String s,int s2");
	}
	

	public static void main(String[] args) {

		m1("ramarao",5);


	}

}
