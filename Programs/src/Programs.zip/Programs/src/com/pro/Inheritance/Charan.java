package com.pro.Inheritance;

public class Charan extends Chiru {
	
public void m1(String a) {
		
		System.out.println("in charan");
	}

//public void m2(String a) {
//	
//	System.out.println("in charan");
//}
	
	public static void main(String[] args) {
		
//		Charan c = new  Charan();
//		c.m1("abc");
		
//		Chiru c = new Chiru();
//		c.m1("abc");
		
//		Chiru c = new Charan();
//		c.m2("abc");
		
//		Charan c = (Charan) new Chiru();
			
	}

}
