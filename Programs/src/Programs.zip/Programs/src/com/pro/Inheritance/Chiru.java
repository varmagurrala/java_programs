package com.pro.Inheritance;

public class Chiru {
	
	public void m1(String a) {
		
		System.out.println("in chiru");
	}
	
public void m1(String a,int b) {
		
		System.out.println("in chiru");
	}

}
