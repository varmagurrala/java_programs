package com.pro.general;

public class SumOfNaturalNumbers {
    public static void main(String[] args) {
        int n = 100;
        
        // Calculate the sum of natural numbers from 1 to n
        int sum = calculateSum(n);

        // Print the result
        System.out.println("Sum of natural numbers from 1 to " + n + ": " + sum);
    }

    private static int calculateSum(int n) {
        // Using the formula for the sum of an arithmetic series: sum = (n * (n + 1)) / 2
        int sum = (n * (n + 1)) / 2;
        return sum;
    }
}

