package com.pro.general;

public class FindFibanacciSeries {
	
	public static void main(String[] args) {
		febSeries(10);
		
	}
	
	public static void febSeries(int n) {
		
		int first=0; 
		int second =1;
		int temp=0;
		for(int i=0;i<n;i++) {
			
			System.out.print(first+",");
			temp=first+second;
			first=second;
			second=temp;
			
		}
		
	
	}

}
