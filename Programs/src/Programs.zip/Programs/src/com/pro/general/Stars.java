package com.pro.general;

public class Stars {
	public static void main(String[] args) {
		stars1();
		
	}
	
	public static void stars1() {
		
		int num=5;
		for(int i=1;i<=num;i++) {
			
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
for(int i=num;i>=1;i--) {
			
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	
		
	}

}
