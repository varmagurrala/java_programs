package com.pro.general;

import java.util.ArrayList;
import java.util.List;

public class InnerClassEx {
    private List<Item> items = new ArrayList<>();

    public void addItem(String name, double price) {
        items.add(new Item(name, price));
    }

    public void displayItems() {
        for (Item item : items) {
            System.out.println(item.name + " - $" + item.price);
        }
    }

    // Inner class representing an item in the shopping cart
    private class Item {
        private String name;
        private double price;	

        public Item(String name, double price) {
            this.name = name;
            this.price = price;
        }
    }

    public static void main(String[] args) {
    	InnerClassEx cart = new InnerClassEx();
        cart.addItem("Laptop", 999.99);
        cart.addItem("Headphones", 49.99);
        cart.displayItems();
    }
}

