package com.pro.general;

public class CopyConstructorEx {
	
	int value;
	
	public CopyConstructorEx(int value) {
		this.value=value;
	}
	
	public CopyConstructorEx(CopyConstructorEx constructorEx) {
		this.value=constructorEx.value;
	}
	
	public void setValue(int value) {
		this.value=value;
	}
	
	

	public static void main(String[] args) {

		
		CopyConstructorEx ex = new CopyConstructorEx(5);
		CopyConstructorEx ey= new CopyConstructorEx(ex);
		System.out.println(ex.value);
		System.out.println(ey.value);
		ex.setValue(10);
		System.out.println(ex.value);
		System.out.println(ey.value);
		System.out.println(ex.value);
	}

}
